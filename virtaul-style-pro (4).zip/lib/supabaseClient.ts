import { createClient } from '@supabase/supabase-js';

// Central configuration for API keys and feature flags
const SUPABASE_URL = 'https://oaunoorxnorgezubthqq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9hdW5vb3J4bm9yZ2V6dWJ0aHFxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUwMjgyNjUsImV4cCI6MjA4MDYwNDI2NX0.thx45RSAj4DTEX_wyze44JN2kaz_O8ueeK3UsgqgSfw';


if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    throw new Error("Supabase URL and Anon Key must be provided.");
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);