import { GoogleGenAI } from "@google/genai";
import type { Outfit } from '../types';

export const findMatchingOutfits = async (prompt: string, outfits: Outfit[]): Promise<Outfit[]> => {
  if (!prompt || outfits.length === 0) {
    return [];
  }

  // Minimize token count by sending only essential fields
  const simplifiedOutfits = outfits.map(({ id, name, category, gender }) => ({ id, name, category, gender }));

  const systemInstruction = `Select the 2 best outfits from the JSON list that match the user's request.
  - Return ONLY a JSON array of the 2 complete outfit objects. 
  - No markdown, no text.
  - Match gender, style, and category.
  - Prioritize precise matches.`;

  const contents = `Request: "${prompt}"\nList: ${JSON.stringify(simplifiedOutfits)}`;

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text?.trim();
    if (!responseText) {
      throw new Error("Empty AI response.");
    }
    
    // Cleanup any markdown code blocks if present
    const jsonString = responseText.replace(/^```json\s*|```$/g, '');
    const matchedOutfitIds = JSON.parse(jsonString).map((item: any) => item.id);

    if (!Array.isArray(matchedOutfitIds)) {
        throw new Error("Invalid array format.");
    }

    const result = matchedOutfitIds
        .map((id: number) => outfits.find(o => o.id === id))
        .filter((o): o is Outfit => o !== undefined);

    return result.slice(0, 2);

  } catch (error) {
    console.error("AI search failed, falling back to keywords:", error);
    const keywords = prompt.toLowerCase().split(/\s+/);
    return outfits
      .map(outfit => {
        const score = keywords.reduce((acc, keyword) => {
          if (outfit.name.toLowerCase().includes(keyword)) acc++;
          if (outfit.category.toLowerCase().includes(keyword)) acc++;
          return acc;
        }, 0);
        return { ...outfit, score };
      })
      .filter(outfit => outfit.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 2);
  }
};


export const getGeminiChatResponse = async (prompt: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text ?? "I'm not sure how to respond.";
  } catch (error) {
    console.error("Gemini chat error:", error);
    return "I'm having trouble connecting to the AI service right now.";
  }
};

/**
 * Generates platform-specific social media captions for a given garment.
 * @param garmentName The name of the clothing item.
 * @returns A promise that resolves to an object with captions for different platforms.
 */
export const generateSocialMediaCaptions = async (garmentName: string): Promise<{ [key: string]: string }> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const systemInstruction = `Generate 3 short, engaging captions (instagram, twitter, facebook) for a virtual try-on of a "${garmentName}". Return JSON only. Keys: instagram, twitter, facebook.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Captions for "${garmentName}"`,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
      },
    });

    const responseText = response.text?.trim();
    if (!responseText) return { instagram: "", twitter: "", facebook: "" };

    const jsonString = responseText.replace(/^```json\s*|```$/g, '');
    return JSON.parse(jsonString);

  } catch (error) {
    console.error("Caption generation error:", error);
    const fallback = `Loving my new look with this ${garmentName}! #StyleSenseAI`;
    return { instagram: fallback, twitter: fallback, facebook: fallback };
  }
};