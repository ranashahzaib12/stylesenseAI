import { useState, useEffect } from 'react';
import type { WeatherData, LocationData } from '../types';
import { WEATHER_API_KEY } from '../config';

interface WeatherHookResult {
    weather: WeatherData | null;
    location: LocationData | null;
    loading: boolean;
    error: string | null;
    isFallback: boolean;
}

const useWeather = (): WeatherHookResult => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [location, setLocation] = useState<LocationData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFallback, setIsFallback] = useState(false);

  const setFallbackData = (errorMessage?: string) => {
      if (errorMessage) setError(errorMessage);
      setWeather({ temp: 18, description: 'Mild day', icon: '🌤️' });
      setLocation({ name: 'Default', country: 'Location'});
      setIsFallback(true);
      setLoading(false);
  }

  useEffect(() => {
    // FIX: Removed check for placeholder API key as it causes a type error once the key is set.
    if (!WEATHER_API_KEY) {
        console.warn("Weather API key not found or is a placeholder. Using default weather data.");
        setFallbackData("Weather API key is not configured. Please add it to `config.ts`.");
        return;
    }

    if (!navigator.geolocation) {
      setFallbackData("Geolocation is not supported by your browser.");
      return;
    }

    const fetchWeatherData = async (position: GeolocationPosition) => {
      try {
        const { latitude, longitude } = position.coords;
        const response = await fetch(`https://api.weatherapi.com/v1/current.json?key=${WEATHER_API_KEY}&q=${latitude},${longitude}`);
        if (!response.ok) {
          throw new Error('Weather data not available');
        }
        const data = await response.json();
        setWeather({
          temp: data.current.temp_c,
          description: data.current.condition.text,
          icon: data.current.condition.icon,
        });
        setLocation({
            name: data.location.name,
            country: data.location.country,
        });
        setIsFallback(false);
      } catch (e) {
        setFallbackData(e instanceof Error ? e.message : 'Failed to fetch weather data');
      } finally {
        setLoading(false);
      }
    };

    const handleLocationError = (error: GeolocationPositionError) => {
      setFallbackData(`Error getting location: ${error.message}`);
    };

    navigator.geolocation.getCurrentPosition(fetchWeatherData, handleLocationError);

  }, []);

  return { weather, location, loading, error, isFallback };
};

export default useWeather;