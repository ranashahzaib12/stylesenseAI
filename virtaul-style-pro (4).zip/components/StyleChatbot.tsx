import React, { useState, useEffect, useRef } from 'react';
import { sendMessageToHuggingFace } from '../services/huggingFaceService';
import { getGeminiChatResponse } from '../services/geminiService';
import type { ChatMessage } from '../types';
import { useAppContext } from '../contexts/AppContext';
import { USE_GEMINI_CHATBOT } from '../constants';

const Message: React.FC<{ message: ChatMessage }> = ({ message }) => {
  const isUser = message.sender === 'user';
  return (
    <div className={`flex items-end ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`px-4 py-2 rounded-2xl max-w-sm md:max-w-md lg:max-w-lg shadow-sm ${
          isUser
            ? 'bg-primary text-white rounded-br-none'
            : 'bg-background text-textPrimary border border-textSecondary/10 rounded-bl-none'
        }`}
      >
        {message.text}
      </div>
    </div>
  );
};

const StyleChatbot: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { weather, location, quizDetails, generatedOutfits, triedOnOutfits } = useAppContext();

  useEffect(() => {
    setMessages([{ sender: 'bot', text: "Hi! I'm StyleBot. How can I help you with your fashion questions today?" }]);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    let contextSummary = "You are StyleBot, a friendly and knowledgeable fashion advisor. Provide concise, helpful, and encouraging style tips. Keep your responses to 2-4 sentences. Use the following context about the user to personalize your response:\n";
    if (location) {
        contextSummary += `- User's location: ${location.name}, ${location.country}.\n`;
    }
    if (weather) {
        contextSummary += `- Current weather: ${weather.temp}°C, ${weather.description}.\n`;
    }
    if (quizDetails) {
        contextSummary += `- User's quiz results: Prefers a ${quizDetails.vibe} style and has a ${quizDetails.bodyType} body type.\n`;
    }
    if (generatedOutfits.length > 0) {
        contextSummary += `- User has recently generated ${generatedOutfits.length} outfit(s).\n`;
    }
    if (triedOnOutfits.length > 0) {
        contextSummary += `- User has recently tried on ${triedOnOutfits.length} outfit(s) virtually.\n`;
    }
    
    let botResponseText = '';

    if (USE_GEMINI_CHATBOT) {
        const fullPrompt = `${contextSummary}\n\nUser question: "${input}"`;
        botResponseText = await getGeminiChatResponse(fullPrompt);
    } else {
        const fullPrompt = `${contextSummary}\n[INST] ${input} [/INST]`;
        botResponseText = await sendMessageToHuggingFace(fullPrompt);
    }

    const botMessage: ChatMessage = { sender: 'bot', text: botResponseText };
    setMessages(prev => [...prev, botMessage]);
    setLoading(false);
  };
  
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !loading) {
      handleSend();
    }
  };

  return (
    <div className="max-w-2xl mx-auto h-[75vh] flex flex-col animate-fade-in">
      <div className="text-center mb-4">
        <h2 className="text-3xl font-bold text-textPrimary">Style Chatbot</h2>
        <p className="mt-1 text-md text-textSecondary">Your personal AI fashion advisor.</p>
      </div>
      <div className="flex-1 bg-surface rounded-xl shadow-lg p-4 flex flex-col border border-textSecondary/5">
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.map((msg, index) => (
            <Message key={index} message={msg} />
          ))}
          {loading && (
             <div className="flex items-end justify-start">
                <div className="px-4 py-2 rounded-2xl max-w-sm bg-background border border-textSecondary/10 rounded-bl-none">
                   <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-textSecondary rounded-full animate-pulse"></div>
                        <div className="w-2 h-2 bg-textSecondary rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                        <div className="w-2 h-2 bg-textSecondary rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                   </div>
                </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        <div className="mt-4 border-t border-textSecondary/10 pt-4 flex items-center">
          <input
            type="text"
            className="flex-1 appearance-none border border-textSecondary/20 rounded-full py-2 px-4 bg-background text-textPrimary placeholder-textSecondary/50 focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="Ask a style question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={loading}
          />
          <button
            onClick={handleSend}
            disabled={loading}
            className="ml-3 inline-flex items-center justify-center rounded-full h-10 w-10 bg-primary text-white hover:bg-primary/90 disabled:opacity-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-sm"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default StyleChatbot;