import React, { useState, useEffect, useRef } from 'react';

interface Props {
  onCapture: (imageDataUrl: string) => void;
  onClose: () => void;
}

const CameraCapture: React.FC<Props> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [hasMultipleCameras, setHasMultipleCameras] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    navigator.mediaDevices.enumerateDevices()
      .then(devices => {
        const videoInputs = devices.filter(device => device.kind === 'videoinput');
        setHasMultipleCameras(videoInputs.length > 1);
      });
  }, []);
  
  const stopStream = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const startCamera = async (mode: 'user' | 'environment') => {
    stopStream(); // Stop any existing stream
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
      }
      setStream(newStream);
      setError(null);
    } catch (err) {
      console.error("Camera error:", err);
      let message = "Could not access camera. Please ensure permissions are granted in your browser settings.";
      if (err instanceof Error && err.name === 'NotAllowedError') {
          message = "Camera access denied. Please enable camera permissions to use this feature.";
      }
      setError(message);
    }
  };

  useEffect(() => {
    startCamera(facingMode);
    return () => stopStream();
  }, [facingMode]);

  const handleSwitchCamera = () => {
    setFacingMode(prev => (prev === 'user' ? 'environment' : 'user'));
  };

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        
        // Flip the image horizontally if it's the front camera for a correct orientation
        if (facingMode === 'user') {
          context.translate(videoRef.current.videoWidth, 0);
          context.scale(-1, 1);
        }

        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.9);
        onCapture(dataUrl);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex flex-col items-center justify-center animate-fade-in p-4" onClick={onClose}>
      <div className="relative bg-black rounded-lg w-full max-w-2xl aspect-video overflow-hidden shadow-2xl" onClick={e => e.stopPropagation()}>
        {error ? (
          <div className="flex flex-col items-center justify-center h-full text-white p-4 text-center">
              <p className="text-lg text-error">{error}</p>
              <button onClick={onClose} className="mt-4 px-4 py-2 bg-primary text-white font-semibold rounded-lg">Close</button>
          </div>
        ) : (
          <>
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <canvas ref={canvasRef} className="hidden" />
          </>
        )}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent flex items-center justify-center">
            <div className="absolute left-4 bottom-4">
                {hasMultipleCameras && !error && (
                    <button onClick={handleSwitchCamera} className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-white backdrop-blur-sm" aria-label="Switch Camera">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5M4 20h5v-5M20 4h-5v5" /></svg>
                    </button>
                )}
            </div>
            {!error && (
                <button onClick={handleCapture} className="w-20 h-20 bg-white rounded-full border-4 border-black/30 ring-4 ring-white/30" aria-label="Capture Photo"></button>
            )}
            <div className="absolute right-4 bottom-4">
                 <button onClick={onClose} className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-white backdrop-blur-sm" aria-label="Close Camera">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                 </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default CameraCapture;