import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import Spinner from '../Spinner';

const RegisterForm: React.FC<{ onSwitchToLogin: () => void }> = ({ onSwitchToLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const { register } = useAuth();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setRegistrationSuccess(false);

    if (password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }
    
    setLoading(true);
    const { data, error } = await register({ email, password });
    
    if (error) {
      setError(error.message);
    } else if (data.user) {
      // Handle success: A user object exists, but they may need to confirm their email.
      setRegistrationSuccess(true);
    }
    setLoading(false);
  };
  
  if (registrationSuccess) {
    return (
        <div className="text-center space-y-4 animate-fade-in">
            <svg className="mx-auto h-12 w-12 text-success" xmlns="http://www.w.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h2 className="text-xl font-semibold text-textPrimary">Account Created!</h2>
            <p className="text-sm text-textSecondary">
                Please check your email inbox for a verification link to complete your registration.
            </p>
            <button
                onClick={onSwitchToLogin}
                className="font-medium text-primary hover:underline"
            >
                Return to Sign In
            </button>
        </div>
    );
  }

  return (
    <form onSubmit={handleRegister} className="space-y-6">
      <h2 className="text-xl font-semibold text-center text-textPrimary">Create an Account</h2>
      {error && (
        <div className="bg-error/10 border border-error text-error text-sm rounded-lg p-3 text-center">
          {error}
        </div>
      )}
      <div>
        <label htmlFor="email-reg" className="text-sm font-medium text-textPrimary">Email</label>
        <input
          id="email-reg"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1 w-full bg-background border border-textSecondary/20 rounded-md shadow-sm py-2 px-3 text-textPrimary focus:outline-none focus:ring-2 focus:ring-primary"
          required
        />
      </div>
      <div>
        <label htmlFor="password-reg"  className="text-sm font-medium text-textPrimary">Password</label>
        <div className="relative">
          <input
            id="password-reg"
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full bg-background border border-textSecondary/20 rounded-md shadow-sm py-2 px-3 text-textPrimary focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
          <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 px-3 flex items-center text-textSecondary">
            {showPassword ? 'Hide' : 'Show'}
          </button>
        </div>
      </div>
      <button
        type="submit"
        disabled={loading}
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loading ? <Spinner /> : 'Create Account'}
      </button>
      <p className="text-center text-sm text-textSecondary">
        Already have an account?{' '}
        <button type="button" onClick={onSwitchToLogin} className="font-medium text-primary hover:underline">
          Sign In
        </button>
      </p>
    </form>
  );
};

export default RegisterForm;