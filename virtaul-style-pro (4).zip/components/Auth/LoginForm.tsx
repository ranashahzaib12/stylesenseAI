import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import Spinner from '../Spinner';

const LoginForm: React.FC<{ onSwitchToRegister: () => void }> = ({ onSwitchToRegister }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { login } = useAuth();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email || !password) {
        setError("Please enter both email and password.");
        return;
    }
    
    setLoading(true);
    const { error } = await login({ email, password });
    if (error) {
      setError(error.message);
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleLogin} className="space-y-6">
      <h2 className="text-xl font-semibold text-center text-textPrimary">Welcome Back</h2>
      {error && (
        <div className="bg-error/10 border border-error text-error text-sm rounded-lg p-3 text-center">
          {error}
        </div>
      )}
      <div>
        <label htmlFor="email" className="text-sm font-medium text-textPrimary">Email</label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1 w-full bg-background border border-textSecondary/20 rounded-md shadow-sm py-2 px-3 text-textPrimary focus:outline-none focus:ring-2 focus:ring-primary"
          required
        />
      </div>
      <div>
        <label htmlFor="password"  className="text-sm font-medium text-textPrimary">Password</label>
        <div className="relative">
          <input
            id="password"
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full bg-background border border-textSecondary/20 rounded-md shadow-sm py-2 px-3 text-textPrimary focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
          <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 px-3 flex items-center text-textSecondary">
            {showPassword ? 'Hide' : 'Show'}
          </button>
        </div>
      </div>
      <button
        type="submit"
        disabled={loading}
        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loading ? <Spinner /> : 'Sign In'}
      </button>
      <p className="text-center text-sm text-textSecondary">
        Don't have an account?{' '}
        <button type="button" onClick={onSwitchToRegister} className="font-medium text-primary hover:underline">
          Sign Up
        </button>
      </p>
    </form>
  );
};

export default LoginForm;