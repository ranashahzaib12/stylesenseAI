import React, { useState } from 'react';
import { TryOnJob } from '../../types';
import { useAppContext } from '../../contexts/AppContext';
import StyleShareModal from '../Share/StyleShareModal';

const JobItem: React.FC<{ job: TryOnJob }> = ({ job }) => {
  const { retryTryOnJob } = useAppContext();
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  return (
    <>
      {job.status === 'completed' && job.resultImage && (
        <StyleShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          resultImage={job.resultImage}
          garmentName={job.garment.name}
        />
      )}
      <div className="bg-background p-4 rounded-lg flex flex-col sm:flex-row items-center gap-4 animate-fade-in border border-textSecondary/10">
        <div className="relative flex-shrink-0">
          <img src={job.personImage} alt="Your photo" className="w-24 h-24 object-cover rounded-lg" />
          <img src={job.garment.imageUrl} alt={job.garment.name} className="absolute w-10 h-10 -bottom-2 -right-2 rounded-md border-2 border-surface shadow-lg" />
        </div>
        <div className="flex-grow text-center sm:text-left">
          <p className="font-semibold text-textPrimary">{job.garment.name}</p>
          <p className="text-xs text-textSecondary">
             {job.status === 'completed' ? 'Ready to wear' : job.status === 'processing' ? 'Creating your look...' : 'Something went wrong'}
          </p>
        </div>
        <div className="w-full sm:w-auto sm:max-w-xs flex-shrink-0 flex justify-center sm:justify-end">
          {job.status === 'processing' && (
            <div className="flex items-center justify-center gap-3 p-2 rounded-lg bg-primary/10 text-primary">
              <div className="w-5 h-5 border-2 border-dashed rounded-full animate-spin border-current"></div>
              <span className="font-medium text-sm">Processing...</span>
            </div>
          )}
          {job.status === 'failed' && (
            <div className="flex flex-col items-center gap-2">
                 <div className="p-2 rounded-lg bg-error/10 text-error text-center">
                    <p className="font-medium text-sm">Failed</p>
                 </div>
                 <button 
                    onClick={() => retryTryOnJob(job.id)} 
                    className="flex items-center gap-1 text-sm text-error hover:text-red-700 hover:underline"
                 >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 110 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
                    </svg>
                    Retry
                 </button>
            </div>
          )}
          {job.status === 'completed' && job.resultImage && (
            <div className="flex flex-col sm:flex-row items-center gap-2">
                <img src={job.resultImage} alt="Completed try-on" className="w-20 h-20 object-cover rounded-lg shadow-md border border-textSecondary/10" />
                 <button
                    onClick={() => setIsShareModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-primary text-white text-sm font-bold rounded-lg hover:bg-primary/90 shadow-sm transition-transform hover:scale-105"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                    </svg>
                    Share
                </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default JobItem;