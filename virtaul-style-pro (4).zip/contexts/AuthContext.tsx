import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { Session, User, SignInWithPasswordCredentials, SignUpWithPasswordCredentials } from '@supabase/supabase-js';

interface AuthContextType {
    user: User | null;
    session: Session | null;
    loading: boolean;
    login: (credentials: SignInWithPasswordCredentials) => Promise<any>;
    register: (credentials: SignUpWithPasswordCredentials) => Promise<any>;
    logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    const [session, setSession] = useState<Session | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Supabase's onAuthStateChange listener is called once on subscription with the current session.
        // This single listener handles both the initial session check and any subsequent auth state changes,
        // ensuring a user is automatically logged in if a valid session exists.
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            setSession(session);
            setUser(session?.user ?? null);
            setLoading(false);
        });

        return () => {
            subscription?.unsubscribe();
        };
    }, []);
    
    const login = (credentials: SignInWithPasswordCredentials) => supabase.auth.signInWithPassword(credentials);
    
    const register = (credentials: SignUpWithPasswordCredentials) => supabase.auth.signUp(credentials);

    const logout = async () => {
        await supabase.auth.signOut();
    };

    const value = {
        user,
        session,
        loading,
        login,
        register,
        logout,
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};